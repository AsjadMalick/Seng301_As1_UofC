/**
 * SENG 301
 * Asjad Malick
 * 300022229
 * Assignment 1
 * W17, Tony Tang
 */

 //Import necessary libraries
using System.Collections;
using System.Collections.Generic;
using Frontend1;
using System;
using System.Linq;

namespace seng301_asgn1 {
    /// <summary>
    /// Represents the concrete virtual vending machine factory that you will implement.
    /// This implements the IVendingMachineFactory interface, and so all the functions
    /// are already stubbed out for you.
    /// 
    /// Your task will be to replace the TODO statements with actual code.
    /// 
    /// Pay particular attention to extractFromDeliveryChute and unloadVendingMachine:
    /// 
    /// 1. These are different: extractFromDeliveryChute means that you take out the stuff
    /// that has already been dispensed by the machine (e.g. pops, money) -- sometimes
    /// nothing will be dispensed yet; unloadVendingMachine is when you (virtually) open
    /// the thing up, and extract all of the stuff -- the money we've made, the money that's
    /// left over, and the unsold pops.
    /// 
    /// 2. Their return signatures are very particular. You need to adhere to this return
    /// signature to enable good integration with the other piece of code (remember:
    /// this was written by your boss). Right now, they return "empty" things, which is
    /// something you will ultimately need to modify.
    /// 
    /// 3. Each of these return signatures returns typed collections. For a quick primer
    /// on typed collections: https://www.youtube.com/watch?v=WtpoaacjLtI -- if it does not
    /// make sense, you can look up "Generic Collection" tutorials for C#.
    /// </summary>
    /// 

        //This class implements the IVendingMachineFactory
    public class VendingMachineFactory : IVendingMachineFactory {

        //A list of machines that the factory has created
        private List<VendingMachineObject> machineList;

        //Constructor
        //Just initializes machine list
        public VendingMachineFactory() {
            machineList = new List<VendingMachineObject>();
        }

        /// This method creates a vendingMachineObject and adds it to the machine List
        /// <param name="coinKinds">List of integers that represent the coin values 
        ///   accepted by the vending machine.</param>
        /// <param name="selectionButtonCount">Number of pop selection buttons the vending
        ///   machine has.</param>
        /// <returns>An index referring to this specific vending machine.</returns>
        public int createVendingMachine(List<int> coinKinds, int selectionButtonCount) {

            //Create a vending machine with the parameters
            VendingMachineObject VM = new VendingMachineObject(coinKinds, selectionButtonCount);

            //Add the machine to machineList
            machineList.Add(VM);

            //Return the index of the machine in the list
            return machineList.IndexOf(VM);
        }

        /// This method configures a vending machine object with some pop types and prices of those types
        /// <param name = "vmIndex" > An index referring to a vending machine.</param>
        /// <param name="popNames">List of strings that represents the names of pops
        ///   sold by this vending machine.</param>
        /// <param name="popCosts">List of integers that represent the cost for each
        ///   of the pops.</param>
        public void configureVendingMachine(int vmIndex, List<string> popNames, List<int> popCosts) {

            //Get the specified machine from machineList
            VendingMachineObject VM = machineList.ElementAt(vmIndex);

            //If the lists are of different lengths then throw an exception
            if(popNames.Count != popCosts.Count)
            {
                throw new Exception("List of names is not the same length as prices for pop");
            }
            else
            {
                //Check all prices to see if they are negative, if one of them is, throw an exception
                foreach(int i in popCosts)
                {
                    if(i <= 0)
                    {
                        throw new Exception("A price of pop was zero or negative");
                    }
                }

                //Iterate through both lists
                for(int i = 0; i < popCosts.Count; i++)
                {
                    //Create a pop using the ith name in list
                    Pop p = new Pop(popNames.ElementAt(i));

                    //Get ith price of Pop p
                    int price = popCosts.ElementAt(i);

                    //Call the configureprices method on the machine
                    VM.configurePrices(p, price);
                }
            }
        }
        
        /// Loads coins into the specified vending machine into the specified coin chute. 
        /// <param name = "vmIndex" > An index referring to a vending machine.</param>
        /// <param name="coinKindIndex">An index referring to a specific coin chute in 
        ///   the vending machine</param>
        /// <param name="coins">A list of coins to load into the coin chute</param>
        public void loadCoins(int vmIndex, int coinKindIndex, List<Coin> coins) {
            
            // Get specified machine from machineList
            VendingMachineObject VM = machineList.ElementAt(vmIndex);

            //Use the machine's loadCoins method with the same parameters
            VM.loadCoins(coinKindIndex, coins);
        }

        /// Loads pops into the specified vending machine into the specified pop chute.
        /// <param name="vmIndex">An index referring to a vending machine.</param>
        /// <param name="popKindIndex">An index referring to a specific pop chute in
        ///   the vending machine</param>
        /// <param name="pops">A list of pops to load into the pop chute</param>
        public void loadPops(int vmIndex, int popKindIndex, List<Pop> pops) {

            //Get specified machine from machineList
            VendingMachineObject VM = machineList.ElementAt(vmIndex);

            //Call the machine's loadpop method with the parameters provided
            VM.loadPop(popKindIndex, pops);
        }

        /// Inserts a coin into the specified vending machine.
        /// If the coin is not one of the accepted coin types, then it is dispensed
        /// immediately into the delivery chute.
        /// 
        /// <param name="vmIndex">An index referring to a vending machine.</param>
        /// <param name="coin">The coin that will be inserted into the vending 
        ///   machine</param>
        public void insertCoin(int vmIndex, Coin coin) {

            // Get specified machine from machineList
            VendingMachineObject VM = machineList.ElementAt(vmIndex);

            //If the coin is valid for this machine
            if(VM.getCoinKindVal().Contains(coin.Value))
            {
                //then call the machine's insert coin method
                VM.insertCoin(coin);
            }
            else
            {
                //Otherwise send the coin to the delivery chute
                VM.deliver(coin);
            }
        }

        /// Presses a button on the specified vending machine
        /// <param name="vmIndex">An index referring to a vending machine.</param>
        /// <param name="value">An index of the button to be pressed (0-indexed)</param>
        public void pressButton(int vmIndex, int value) {

            //Throw excpetion if index was negative
            if (value < 0)
            {
                throw new Exception("Button index was negative");
            }

            //Get specified machine from machineList
            VendingMachineObject VM = machineList.ElementAt(vmIndex);

            //Throw exeption if index is out of bounds of machine
            if(value >= VM.getButtons())
            {
                throw new Exception("Button index must be less than number of buttons");
            }

            //Otherwise call the purchase method of the machine
            VM.purchase(value);
        }

        /// Takes everything out of the vending machine's dispenser hopper, including 
        /// coins (either change or coin types that we don't accept) and pops dispensed
        /// <param name="vmIndex">An index referring to a vending machine.</param>
        /// <returns>A flat list of pops and coins that have been dispensed</returns>
        public List<Deliverable> extractFromDeliveryChute(int vmIndex) {

            //Get the machine specified from machine List
            VendingMachineObject VM = machineList.ElementAt(vmIndex);
            
            //Return the machine's deliverychute/hopper
            return VM.DeliveryChute();
        }

        /// Unloads a vending machine of all its contents: money that is still in the
        /// change maker, money that we have made, and all the unsold pops.
        ///
        /// <param name="vmIndex">An index referring to a vending machine.</param>
        /// <returns>A three-tuple list of strongly-typed lists that represents the
        ///   remaining money in the change maker, the money we have made from dispensed
        ///   pops, and unsold pops. Each of these three things is its own List in that
        ///   order.</returns>
        public List<IList> unloadVendingMachine(int vmIndex) {

            //Get specified machine from machine list
            VendingMachineObject VM = machineList.ElementAt(vmIndex);

            //Return the list created by the unloadMachine method of the machine
            return VM.unloadMachine();
            }
    }
}