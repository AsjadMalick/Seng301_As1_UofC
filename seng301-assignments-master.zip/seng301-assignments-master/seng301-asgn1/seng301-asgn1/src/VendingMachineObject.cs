﻿/**
 * SENG 301
 * Asjad Malick
 * 300022229
 * Assignment 1
 * W17, Tony Tang
 */

// Importing the necessary libraries 
using System;
using System.Collections.Generic;
using System.Linq;
using Frontend1;
using System.Collections;

//The same namespace as the vending machine factory class
namespace seng301_asgn1
{
    /**
     * The class creates an object that will be made by the factory class. 
     * It will contain fields to store necessary info
     */
    class VendingMachineObject
    {
        //A list storing the values of the types of coins the machine can accept
        private List<int> coinKindVal;
        
        //A 'getter' method for coinKindVal
        public List<int> getCoinKindVal() { return this.coinKindVal; }

        //The number of buttons to select drinks on the machine
        private int buttons;

        //A 'getter' for the buttons variable
        public int getButtons() { return this.buttons; }

        //A list to hold the possible kinds of pops
        private List<Pop> popList;

        //An integer keeping track of the total value of coins entered for current purchase
        private int coinsInserted;

        //A list of coins keeping track of the Coin objects inserted for current purchase. 
        private List<Coin> coinsInsertedList;

        //List keeping track of ALL coin objects inseretd into machine
        private List<Coin> totalProfit;

        //A map to keep track of the prices associated with each pop
        private Dictionary<String, int> popPrices;

        //An array of a lists of coins to represent the chutes that contain change
        private List<Coin>[] changeChuteList;

        //An array of a lists of pops to represent the chutes that contain the pop to be sold.
        private List<Pop>[] popChuteList;

        //A list of deliverables that represent the contents of the delivery chute
        private List<Deliverable> deliveryChute;

        //A 'getter' method for the delivery chute
        public List<Deliverable> DeliveryChute() { return this.deliveryChute; }

        /**
         * Constructor for the vending machine onject class
         * Parameters: coinValList, a list of integers reprsenting possible coin values
         * b: integer representing number of buttons for pop selection
         */
        public VendingMachineObject (List<int> coinValList, int b)
        {
            //Initializing the coinKindVal list
            coinKindVal = new List<int>();

            //Check to see if elements in the list are distinct or not.
            //If not then an exception is thrown.
            if (coinValList.Count() != coinValList.Distinct().Count())
            {
                throw new Exception("Duplicate coin types exist in the list, Cannot create machine");
            }
            else
            {
                //For all integers in input list 
                foreach(int i in coinValList)
                {
                    //First create a coin to make use of the exception handling in Coin class.
                    //This avoids redundancy and if any erros occur the rest of code does not execute.
                    Coin c = new Coin(i);

                    //If no exception was thrown then coin is valid so store the integer in list
                    coinKindVal.Add(i);
                }

                //Sort the list into ascending order, makes it easier to calculate chnage later
                coinKindVal.Sort();
                
                //Initialize buttons variable
                buttons = b;
            
                //Initilaize popList
                popList = new List<Pop>();

                //Initialize the map for pop prices
                popPrices = new Dictionary<String, int>();

                //Initialize the changechuteList array
                changeChuteList = new List<Coin> [coinKindVal.Count];

                for(int i = 0; i < changeChuteList.Count(); i++)
                {
                    //Initialize the individual lists inside the array
                    List<Coin> c = new List<Coin>();
                    changeChuteList[i] = c;
                }

                //Initialize the popChuteList Array
                popChuteList = new List<Pop> [buttons];

                for (int i = 0; i < popChuteList.Count(); i++)
                {
                    //Initialize the individual lists inside the array
                    List<Pop> p = new List<Pop>();
                    popChuteList[i] = p;
                }

                //Initialize the delivery chute
                deliveryChute = new List<Deliverable>();

                //Initialize the coinsInsertedList
                coinsInsertedList = new List<Coin>();

                //Initialize the coinsInserted variable
                coinsInserted = 0;

                //Initialize the totalProfit list
                totalProfit = new List<Coin>();
            }
        }

        /**
         * Method to use when configuring prices for pop 
         * <Param> "P" Pop, the pop type to add to machine </Param>
         * <Param> "price" int, the price of the pop  </Param>
         * Method returns nothing
         */
        public void configurePrices(Pop p, int price)
        {
            //Set the price in the dictionary
            popPrices[p.Name] = price;

            //Add the pop to the list of possible pops
            popList.Add(p);
        }

        /**
         * Method to use when loading coins into change chute 
         * <Param> "indx" int, the index of the chute to load coins into </Param>
         * <Param> "c" List<Coin>, the list of coins to load into chute </Param>
         * Method returns nothing
         */
        public void loadCoins(int indx, List<Coin> c)
        {
            //Set the list at indx position to the value of c
            changeChuteList[indx] = c;
        }

        /**
         * Method to use when loading pops into pop chute 
         * <Param> "indx" int, the index of the chute to load pop into </Param>
         * <Param> "p" List<Pop>, the list of pops to load into chute </Param>
         * Method returns nothing
         */
        public void loadPop(int indx, List<Pop> p)
        {
            //Set the list at indx position to the value of p
            popChuteList[indx] = p;
        }

        /**
         * Method to be used by other classes to send deliverable objects
         * to deliverable chute of this machine.
         * <Param> "d" Deliverable, The object to be sent to delivery Chute</Param>
         * returns nothing 
         */
        public void deliver(Deliverable d)
        {
            //Adds object to the deliveryChute list
            deliveryChute.Add(d);
        }

        /**
         * Method to be used when a coin is being inserted into machine
         * <Param> "c" Coin, the coin to insert </Param>
         * returns nothing
         */
        public void insertCoin(Coin c)
        {
            //Increment the coinsInserted integer by the value of coin to get current
            //paying total
            coinsInserted = coinsInserted + c.Value;

            //Add the coin to the list of coins inserted
            coinsInsertedList.Add(c);
        }

        /**
         * Method to be used when the drink selection button is pressed 
         * <Param> "v" int, the index of the button that is pressed
         * returns nothing
         */
        public void purchase(int v)
        {
            //Get the desired pop from the popList using the parameter as index.
            Pop selectedDrink = popList[v];

            //Get and store name of pop.
            String name = selectedDrink.Name;

            //Get price of pop from dictionary
            int price = popPrices[name];

            //Check to see if more coins need to be inserted, if so, dont do anything
            if(coinsInserted >= price)
            {
                //Get the chute containg the kind of desried pop using index v
                List<Pop> vendingList = popChuteList[v];

                //Check to see if there is still pop inside the chute, if not dont do anything
                //(the machine does not do refunds)
                if (vendingList.Count != 0)
                {
                    //Get the pop at the end of the chute
                    Pop p = vendingList.Last();
                    
                    //Remove the pop from the list
                    vendingList.Remove(p);

                    //Send the pop to delivery chute by adding it to list
                    deliveryChute.Add(p);

                    //If exact change was given otherwise chnage has to be given back to customer
                    if(coinsInserted == price)
                    {
                        foreach( Coin c in coinsInsertedList)
                        {
                            //Add the coins inserted to the total profit list
                            totalProfit.Add(c);
                        }

                        //Clear coins inserted list since purchase has completed 
                        coinsInsertedList.Clear();

                        //Reset the coinsinserted counter
                        coinsInserted = 0;
                    }
                    else
                    {
                        //Calculate change that must be given
                        int change = coinsInserted - price;

                        foreach(Coin c in coinsInsertedList)
                        {
                            //Add the coins inserted to the total profit list
                            totalProfit.Add(c);
                        }

                        //Clear coins inserted list since purchase has completed 
                        coinsInsertedList.Clear();

                        //Reset the coinsinserted counter
                        coinsInserted = 0;

                        int[] indxHolder = new int[changeChuteList.Length];

                        //For loop to iterate through the changeChuteList from the highest index to 0
                      for(int i = coinKindVal.Count - 1; i > -1; i--)
                        {
                            List<Coin> cList = changeChuteList[i];
                            foreach(List<Coin> c in changeChuteList)
                            {
                                if(c.Count != 0)
                                {
                                    int cVal = c.Last().Value;
                                    if(cVal == i)
                                    {
                                        cList = changeChuteList[cVal];
                                    }
                                }
                               
                            }

                            //Set a boolean run to be true, for controlling while loop
                            bool run = true;

                            //While there are still coins inside ith chute and loop control is true.
                            while((cList.Count != 0) && (run == true))
                            {
                                //Grab last coin inside chute
                                Coin c = cList.Last();

                                //If depositing this coin will result in too much change being deposited then
                                //skip the if and go to else clause
                                if((change - c.Value) >= 0)
                                {
                                    //Decrement change by the coin value (the chnage has been paid)
                                    change = change - c.Value;

                                    //Send the coin to the delivery Chute
                                    deliveryChute.Add(c);
                                    
                                    //Remove the coin from the change chute
                                    cList.Remove(c);
                                }
                                else
                                {
                                    //Break the while loop and go to a lower order coin
                                    run = false;
                                }
                            }
                        }
                    }
                   
                }
            }
        }

        /**
         * Method to be used when unloading machine of everything
         * returns List<IList>, A list of 3 lists, the remaining change, the profit coins, the list of unsold pop
         * in that order 
         */
        public List<IList> unloadMachine()
        {
            //Initialize the list that will be returned
            List<IList> ret = new List<IList>();

            //Create a list that will form the first element of ret, the remaining change
            List<Coin> change = new List<Coin>();

            foreach(List<Coin> i in changeChuteList)
            {
                //i a list of coins coresponding to a chute
                foreach(Coin j in i)
                {
                    //j is the coin inside the 'ith' chute
                    //Add j to the chnage list to be returned
                    change.Add(j);
                }
            }
            //Add the change List to the ret list
            ret.Add(change);

            //This loop clears the elements from each indivual list of changeChute
            foreach (List<Coin> i in changeChuteList)
            {
                i.Clear();
            }

            //Clears the array
            Array.Clear(changeChuteList, 0, changeChuteList.Length);

            //Create the list to return the profit coins
            List<Coin> profit = new List<Coin>();

            foreach(Coin i in totalProfit)
            {
                //Add each coin inside totalProfit to profit
                profit.Add(i);
            }

            //Add profit to the returning list
            ret.Add(profit);

            //Clear the elements inside the totalProfit List
            totalProfit.Clear();

            //Create a list to hold the left over pop
            List<Pop> popLeft = new List<Pop>();

            //Similar to the chnageChute i access the elements in a 2 tier fashion
            foreach(List<Pop> i in popChuteList)
            {
                foreach(Pop j in i)
                {
                    //Add the pop left over to the popLeft list
                    popLeft.Add(j);
                }
            }

            //Add popleft list to the returning list
            ret.Add(popLeft);

            //I clear the array in a simialr fashion to chnage chute list
            foreach (List<Pop> i in popChuteList)
            {
                i.Clear();
            }
            Array.Clear(popChuteList, 0, popChuteList.Length);

            //return ret
            return ret;
        }
    }
 }

